/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'nb', {
	label: 'Kopier formatering',
	notification: {
		copied: 'Formatering kopiert',
		applied: 'Formatering tatt i bruk',
		canceled: 'Formatering avbrutt',
		failed: 'Formatering mislyktes. Du kan ikke ta i bruk stiler uten å kopiere dem først.'
	}
} );
