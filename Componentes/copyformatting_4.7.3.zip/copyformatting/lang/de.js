/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'copyformatting', 'de', {
	label: 'Formatierung kopieren',
	notification: {
		copied: 'Formatierung kopiert',
		applied: 'Formatierung angewendet',
		canceled: 'Formatierung abgebrochen',
		failed: 'Formatierung fehlgeschlagen. Sie können Stile nicht anwenden, ohne sie zuerst zu kopieren.'
	}
} );
